package Concesionario;

import java.util.concurrent.Semaphore;

public class Concesionario {

    private int visitantes = 0;
    private final Semaphore semaforo;

    public Concesionario() {
        this.semaforo = new Semaphore(4);
    }

    public void probar(String nombre, int numeroVehiculo) throws InterruptedException {
        try {
            semaforo.acquire();
            System.out.println(nombre + " probando vehiculo " + numeroVehiculo);

            Thread.sleep(3000);

            System.out.println(nombre + " termino de probar el vehiculo " + numeroVehiculo);

        } catch (InterruptedException e) {
            System.err.println("Error en la prueba de vehículo de " + nombre + ": " + e.getMessage());
        } finally {
            semaforo.release();
            System.out.println(nombre + " ha salido del concesionario");

        }
    }
}
