
package Concesionario;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Personas extends Thread {
    private final Concesionario concesionario;
    private final String nombre;
    private final int numeroVehiculo;

    public Personas(Concesionario concesionario, String nombre, int numeroVehiculo) {
        this.concesionario = concesionario;
        this.nombre = nombre;
        this.numeroVehiculo = numeroVehiculo;
    }

    
    @Override 
    public void run(){
        try {
            concesionario.probar(nombre, numeroVehiculo);
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Personas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
