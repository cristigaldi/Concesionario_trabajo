
package Concesionario;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Concesionario concesionario = new Concesionario();
        
        for (int i= 1; i<10; i++){
            Personas persona = new Personas(concesionario, "Persona " + i, i);
            Thread thread = new Thread (persona);
            thread.start();
        }
            
    }

}
